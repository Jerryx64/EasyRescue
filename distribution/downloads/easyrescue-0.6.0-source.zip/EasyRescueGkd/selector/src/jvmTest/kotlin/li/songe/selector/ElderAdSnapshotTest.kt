package li.songe.selector

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.intOrNull
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/** Public historical rule-author snapshots; this exercises the upstream engine, not a phone. */
class ElderAdSnapshotTest {
    private val json = Json { ignoreUnknownKeys = true }
    private val weibo = """@[id="com.sina.weibo:id/btn_close"] - FrameLayout > [id="com.sina.weibo:id/ad_tag"]"""
    private val douyin = """[id="android:id/content"] >2 RelativeLayout[childCount<=5] > @ImageView[clickable=true][id!=null] - TextView[text="广告"][id!=null]"""

    @Test
    fun weiboOriginalSelectorFindsOnlyItsAdCloseControl() {
        assertEquals(listOf(6), query(fixture(12750090), weibo))
    }

    @Test
    fun douyinOriginalSelectorFindsOnlyItsAdCloseControl() {
        assertEquals(listOf(11), query(fixture(12769137), douyin))
    }

    @Test
    fun weiboCloseControlWithoutItsAdMarkerDoesNotMatch() {
        val root = fixture(12750090) { nodes ->
            nodes.map { node -> if (node.id == 8) node.withAttr("id", JsonNull) else node }
        }
        assertTrue(query(root, weibo).isEmpty())
    }

    @Test
    fun douyinCloseControlWithoutItsAdMarkerDoesNotMatch() {
        val root = fixture(12769137) { nodes ->
            nodes.map { node -> if (node.id == 10) node.withAttr("text", JsonNull) else node }
        }
        assertTrue(query(root, douyin).isEmpty())
    }

    @Test
    fun weiboDifferentSiblingOrderDoesNotMatch() {
        val root = fixture(12750090) { nodes ->
            nodes.map { node ->
                when (node.id) {
                    5 -> node.withAttr("index", JsonPrimitive(2))
                    6 -> node.withAttr("index", JsonPrimitive(1))
                    else -> node
                }
            }
        }
        assertTrue(query(root, weibo).isEmpty())
    }

    @Test
    fun douyinAdMarkerAfterAllCloseControlsDoesNotMatch() {
        val root = fixture(12769137) { nodes ->
            nodes.map { node ->
                when (node.id) {
                    10 -> node.withAttr("index", JsonPrimitive(4))
                    11 -> node.withAttr("index", JsonPrimitive(1))
                    12 -> node.withAttr("index", JsonPrimitive(2))
                    13 -> node.withAttr("index", JsonPrimitive(3))
                    else -> node
                }
            }
        }
        assertTrue(query(root, douyin).isEmpty())
    }

    private fun query(root: Node, source: String) =
        transform.querySelectorAll(root, Selector.parse(source)).map { it.id }.toList()

    private fun Node.withAttr(name: String, value: JsonPrimitive) =
        copy(attr = attr + (name to value))

    private fun fixture(id: Int, modify: (List<Node>) -> List<Node> = { it }): Node {
        val raw = requireNotNull(javaClass.getResourceAsStream("/elder-rules/$id.json")) {
            "Missing bundled public snapshot $id"
        }.bufferedReader().use { it.readText() }
        val nodes = modify(json.decodeFromString<Snapshot>(raw).nodes)
        val byId = nodes.associateBy { it.id }
        nodes.forEach { node ->
            node.parent = byId[node.pid]
            node.parent?.children?.add(node)
        }
        nodes.forEach { node -> node.children.sortBy { it.attr["index"]?.intOrNull ?: 0 } }
        return nodes.single { it.pid == -1 }
    }
}
